        <!-- Footer, jossa voisi olla mm. kontaktit -->
        <footer>
            <div class="container">
                <div class="one-half column">
                    <h5>Infoa</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim ex obcaecati facere doloribus at reprehenderit. Praesentium est quam similique dolore sunt saepe harum minima illum mollitia, veniam possimus ad repellendus?</p>
                </div>
                <div class="one-half column">
                    <h5>Kontaktit</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta possimus nam maiores, reiciendis recusandae repellendus ex. Aliquid earum sit dolorum nesciunt expedita repellendus iste accusantium velit omnis, nobis laborum officiis!</p>
                </div>
            </div>
        </footer>
    </body>
</html>