<fieldset><legend>Kirjautumistiedot</legend>
    <form method="post">
        <p>
            Sähköposti 
            <br />
            <input type="text" name="givenEmail" placeholder="voimassa oleva sähköposti" maxlength="40"/>
        </p>
        <p>
            Salasana
            <br />
            <input type="password" name="givenPassword" placeholder="salasana, vähintään 8 merkkiä" maxlength="20"/>
        </p>
        <p>
            <br />
            <input type="submit" name="submitUser" value="Lähetä"/>
            <input type="reset"  value="Tyhjennä"/>
            <input type="submit" name="submitBack" value="Palaa takaisin"/>
        </p>
    </form>
</fieldset>