function confirmEmpty() {
    return confirm("Haluatko varmasti tyhjentää tiedot?");
}