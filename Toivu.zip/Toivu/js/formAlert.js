function formAlert($message) {
    alert($message);
}